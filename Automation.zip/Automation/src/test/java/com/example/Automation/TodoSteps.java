package com.example.Automation;


import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.Assertions;

import java.util.List;
import java.util.Map;

public class TodoSteps {

    private static final double LAT_MIN = -40.0;
    private static final double LAT_MAX = 5.0;
    private static final double LONG_MIN = 5.0;
    private static final double LONG_MAX = 100.0;

    private List<Map<String, Object>> users;
    private List<Map<String, Object>> todos;

    @Given("all users of city {string}")
    public void all_users_of_city(String cityName) {
        users = fetchUsers();
        todos = fetchTodos();
    }

    @When("I calculate their todo completion percentages")
    public void i_calculate_their_todo_completion_percentages() {
        // This step is handled in the Then step
    }

    @Then("each user's completed task percentage should be greater than 50%")
    public void each_user_s_completed_task_percentage_should_be_greater_than_50_percent() {
        for (Map<String, Object> user : users) {
            if (isUserInFanCodeCity(user)) {
                int userId = (int) user.get("id");
                double completionPercentage = calculateCompletionPercentage(userId, todos);
                System.out.printf("User %s has %.2f%% of tasks completed.%n", user.get("name"), completionPercentage);
                Assertions.assertTrue(completionPercentage > 50, 
                        String.format("User %s does not meet the requirement (%.2f%% completed)", user.get("name"), completionPercentage));
            }
        }
    }

    private List<Map<String, Object>> fetchUsers() {
        Response response = RestAssured.get("http://jsonplaceholder.typicode.com/users");
        return response.jsonPath().getList("$");
    }

    private List<Map<String, Object>> fetchTodos() {
        Response response = RestAssured.get("http://jsonplaceholder.typicode.com/todos");
        return response.jsonPath().getList("$");
    }

    private boolean isUserInFanCodeCity(Map<String, Object> user) {
        Map<String, Double> geo = (Map<String, Double>) ((Map<String, Object>) user.get("address")).get("geo");
        double lat = geo.get("lat");
        double lng = geo.get("lng");
        return lat >= LAT_MIN && lat <= LAT_MAX && lng >= LONG_MIN && lng <= LONG_MAX;
    }

    private double calculateCompletionPercentage(int userId, List<Map<String, Object>> todos) {
        long totalTodos = todos.stream().filter(todo -> (int) todo.get("userId") == userId).count();
        long completedTodos = todos.stream().filter(todo -> (int) todo.get("userId") == userId && (boolean) todo.get("completed")).count();
        return totalTodos == 0 ? 0 : (completedTodos * 100.0) / totalTodos;
    }
}

